```python
# Case Study: Help Jeff’s Party Planet to clean its data and analyze it.

## Introduction:
#### Welcome to Jeff’s Party Planet data case study! Jeff’s Party Planet is an event management company that has provided us with the data for cleaning and performing analysis for it. I am assuming I am a freelance junior data analyst who has been approached by Jeff’s Party Planet. The data contains an order listing items ordered for an event, the product quantities ordered, suppliers, price, expenditure per piece, revenue, total expenditure, and profit.
#### To answer the key business questions, I will follow the steps of the data analysis process: ask, prepare, process, analyze, share, and act.
### Scenario:
#### I am a Junior Data Analyst doing freelance data analysis tasks for over a year. I have been recently contacted by Jeff’s Party Planet, a startup event management company. They have recently completed a successful event for their customer. They have provided raw data in a .csv file format containing 34 rows and 8 columns for various products and quantities purchased from four suppliers namely Eco-Disposables, Inflatibles Plus, Sparklefest Ltd., and Supply 4U. The management of Jeff’s Party Planet believes that an analysis of their data will provide them with great insights that will be helpful for their future events. They have asked me to focus on expenditure, profitability, and profit margin per supplier. The insights I discover will help guide their supplier selection strategy for future events.
### Suppliers:
#-	Eco-Disposables, 
#-	Inflatibles Plus, 
#-	Sparklefest Ltd., and 
#-	Supply 4U

#### The Data Analysis Process
#-	ASK
#### The management of Jeff’s Party Planet has asked me to clean their data for any irregularities in the data (if any), and analyze the data to make high-level recommendations for suppliers selection process based on total expenditure, total profit, and profit margin per supplier.

#	Prepare
#### The management of Jeff’s Party Planet has provided me with a dataset in a .csv file format named Jeff_s_Party_Planet.csv through email. I have saved the data in the following location on my laptop f:/Excel Data/ Jeff_s_Party_Planet.csv. They have asked me to clean their data for any irregularities in the data (if any), and analyze the data to make high-level recommendations for suppliers selection process based on total expenditure, total profit, and profit margin per supplier.

```


```python
#-	Process
#### I have decided to use Python Pandas Library to load, clean, and analyze Jeff’s Party Planet dataset. The steps I have taken to process data are listed below:
#### -	Open the already installed Jupiter Notebook

```


```python
# Importing Important Libraries to be used for data cleaning and visualization
import pandas as pd
import matplotlib.pyplot as plt
# Importing warnings library for ignoring unwanted warnings
import warnings
warnings.filterwarnings('ignore')
```


```python
# Loading the Jeff's Party Planet Dataset
# Used encoding='latin1' in order to avoid 'utf-8' codec error
df = pd.read_csv('f:/Excel Data/Jeff_s_Party_Planet.csv', encoding='latin1')
# Displaying dataset in Jupyter Notebook
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Suppliers</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Balloons (100 count)</td>
      <td>776</td>
      <td>Sparklefest Ltd.</td>
      <td>$16.94</td>
      <td>$11.86</td>
      <td>$13,145.44</td>
      <td>$9,201.81</td>
      <td>$3,943.63</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Banners</td>
      <td>236</td>
      <td>Inflatibles Plus</td>
      <td>$3.70</td>
      <td>$2.59</td>
      <td>$873.20</td>
      <td>$611.24</td>
      <td>$261.96</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bounce house</td>
      <td>24</td>
      <td>Inflatibles Plos</td>
      <td>$396.34</td>
      <td>$277.44</td>
      <td>$9,512.16</td>
      <td>$6,658.51</td>
      <td>$2,853.65</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bowls (25 count)</td>
      <td>861</td>
      <td>Eco-Disposables</td>
      <td>$2.27</td>
      <td>$1.59</td>
      <td>$1,954.47</td>
      <td>$1,368.13</td>
      <td>$586.34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Centerpieces</td>
      <td>591</td>
      <td>Sparklefest Ltd.</td>
      <td>$8.26</td>
      <td>$5.78</td>
      <td>$4,881.66</td>
      <td>$3,417.16</td>
      <td>$1,464.50</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Chair covers</td>
      <td>830</td>
      <td>Supply 4U</td>
      <td>$9.37</td>
      <td>$6.56</td>
      <td>$7,777.10</td>
      <td>$5,443.97</td>
      <td>$2,333.13</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Chair cushions</td>
      <td>745</td>
      <td>Supply 4U</td>
      <td>$13.82</td>
      <td>$9.67</td>
      <td>$10,295.90</td>
      <td>$7,207.13</td>
      <td>$3,088.77</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Chairs</td>
      <td>111</td>
      <td>Supply 4U</td>
      <td>$10.95</td>
      <td>$7.67</td>
      <td>$1,215.45</td>
      <td>$850.82</td>
      <td>$364.64</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Coasters (50 count)</td>
      <td>701</td>
      <td>Eco-Disposables</td>
      <td>$3.01</td>
      <td>$2.11</td>
      <td>$2,110.01</td>
      <td>$1,477.01</td>
      <td>$633.00</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Cocktail napkins (100 count)</td>
      <td>985</td>
      <td>Eco-Disposables</td>
      <td>$5.94</td>
      <td>$4.16</td>
      <td>$5,850.90</td>
      <td>$4,095.63</td>
      <td>$1,755.27</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Cocktail plates (40 count)</td>
      <td>928</td>
      <td>Eco-Disposables</td>
      <td>$6.05</td>
      <td>$4.24</td>
      <td>$5,614.40</td>
      <td>$3,930.08</td>
      <td>$1,684.32</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Confetti (65 count)</td>
      <td>603</td>
      <td>Sparklefest Ltd.</td>
      <td>$0.94</td>
      <td>$0.66</td>
      <td>$566.82</td>
      <td>$396.77</td>
      <td>$170.05</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Forks (50 count)</td>
      <td>1065</td>
      <td>Eco-Disposables</td>
      <td>$2.49</td>
      <td>$1.74</td>
      <td>$2,651.85</td>
      <td>$1,856.30</td>
      <td>$795.56</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Goody bags (10 count)</td>
      <td>870</td>
      <td>Eco-Disposables</td>
      <td>$0.82</td>
      <td>$0.57</td>
      <td>$713.40</td>
      <td>$499.38</td>
      <td>$214.02</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Ice buckets</td>
      <td>157</td>
      <td>Inflatibles Plus</td>
      <td>$6.88</td>
      <td>$4.82</td>
      <td>$1,080.16</td>
      <td>$756.11</td>
      <td>$324.05</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Invitations (20 count)</td>
      <td>1209</td>
      <td>Sparklefest Ltd.</td>
      <td>$7.29</td>
      <td>$5.10</td>
      <td>$8,813.61</td>
      <td>$6,169.53</td>
      <td>$2,644.08</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Knives (50 count)</td>
      <td>1015</td>
      <td>Eco-Disposables</td>
      <td>$2.49</td>
      <td>$1.74</td>
      <td>$2,527.35</td>
      <td>$1,769.15</td>
      <td>$758.21</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Ladles</td>
      <td>421</td>
      <td>Inflatibles Plus</td>
      <td>$2.29</td>
      <td>$1.60</td>
      <td>$964.09</td>
      <td>$674.86</td>
      <td>$289.23</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Name tags (20 count)</td>
      <td>281</td>
      <td>Sparklefest Ltd.</td>
      <td>$1.19</td>
      <td>$0.83</td>
      <td>$334.39</td>
      <td>$234.07</td>
      <td>$100.32</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Noisemakers (30 count)</td>
      <td>741</td>
      <td>Sparklefest Ltd.</td>
      <td>$4.27</td>
      <td>$2.99</td>
      <td>$3,164.07</td>
      <td>$2,214.85</td>
      <td>$949.22</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Outdoor heaters</td>
      <td>125</td>
      <td>Inflatibles Plus</td>
      <td>$105.28</td>
      <td>$73.70</td>
      <td>$13,160.00</td>
      <td>$9,212.00</td>
      <td>$3,948.00</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Party hats (10 count)</td>
      <td>808</td>
      <td>Sparklefest Ltd.</td>
      <td>$3.92</td>
      <td>$2.74</td>
      <td>$3,167.36</td>
      <td>$2,217.15</td>
      <td>$950.21</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Piñatas</td>
      <td>867</td>
      <td>Sparklefest Ltd.</td>
      <td>$29.16</td>
      <td>$20.41</td>
      <td>$25,281.72</td>
      <td>$17,697.20</td>
      <td>$7,584.52</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Plates (25 count)</td>
      <td>439</td>
      <td>Eco-Disposables</td>
      <td>$2.03</td>
      <td>$1.42</td>
      <td>$891.17</td>
      <td>$623.82</td>
      <td>$267.35</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Punch bowls</td>
      <td>292</td>
      <td>Inflatibles Plus</td>
      <td>$18.55</td>
      <td>$12.99</td>
      <td>$5,416.60</td>
      <td>$3,791.62</td>
      <td>$1,624.98</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Serving platters</td>
      <td>864</td>
      <td>Inflatibles Plus</td>
      <td>$5.00</td>
      <td>$3.50</td>
      <td>$4,320.00</td>
      <td>$3,024.00</td>
      <td>$1,296.00</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Serving utensils</td>
      <td>127</td>
      <td>Inflatibles Plus</td>
      <td>$3.09</td>
      <td>$2.16</td>
      <td>$392.43</td>
      <td>$274.70</td>
      <td>$117.73</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Spoons (50 count)</td>
      <td>927</td>
      <td>Eco-Disposables</td>
      <td>$2.49</td>
      <td>$1.74</td>
      <td>$2,308.23</td>
      <td>$1,615.76</td>
      <td>$692.47</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Streamers</td>
      <td>566</td>
      <td>Sparklefest Ltd.</td>
      <td>$2.67</td>
      <td>$1.87</td>
      <td>$1,511.22</td>
      <td>$1,057.85</td>
      <td>$453.37</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Table skirts</td>
      <td>1289</td>
      <td>Supply 4U</td>
      <td>$8.50</td>
      <td>$5.95</td>
      <td>$10,956.50</td>
      <td>$7,669.55</td>
      <td>$3,286.95</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Tablecloths</td>
      <td>328</td>
      <td>Supply 4U</td>
      <td>$9.19</td>
      <td>$6.43</td>
      <td>$3,014.32</td>
      <td>$2,110.02</td>
      <td>$904.30</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Tables</td>
      <td>150</td>
      <td>Supply 4U</td>
      <td>$36.20</td>
      <td>$25.34</td>
      <td>$5,430.00</td>
      <td>$3,801.00</td>
      <td>$1,629.00</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Tents</td>
      <td>535</td>
      <td>Inflatibles Plus</td>
      <td>$209.07</td>
      <td>$146.35</td>
      <td>$111,852.45</td>
      <td>$78,296.72</td>
      <td>$33,555.74</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Toothpicks (500 count)</td>
      <td>1386</td>
      <td>Eco-Disposables</td>
      <td>$1.59</td>
      <td>$1.11</td>
      <td>$2,203.74</td>
      <td>$1,542.62</td>
      <td>$661.12</td>
    </tr>
  </tbody>
</table>
</div>




```python
# -	Analyze
#### I have used the following methods to analyze dataset:
```


```python
# 1.	Load leading 8 rows to understand the dataset
df.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Suppliers</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Balloons (100 count)</td>
      <td>776</td>
      <td>Sparklefest Ltd.</td>
      <td>$16.94</td>
      <td>$11.86</td>
      <td>$13,145.44</td>
      <td>$9,201.81</td>
      <td>$3,943.63</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Banners</td>
      <td>236</td>
      <td>Inflatibles Plus</td>
      <td>$3.70</td>
      <td>$2.59</td>
      <td>$873.20</td>
      <td>$611.24</td>
      <td>$261.96</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bounce house</td>
      <td>24</td>
      <td>Inflatibles Plos</td>
      <td>$396.34</td>
      <td>$277.44</td>
      <td>$9,512.16</td>
      <td>$6,658.51</td>
      <td>$2,853.65</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bowls (25 count)</td>
      <td>861</td>
      <td>Eco-Disposables</td>
      <td>$2.27</td>
      <td>$1.59</td>
      <td>$1,954.47</td>
      <td>$1,368.13</td>
      <td>$586.34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Centerpieces</td>
      <td>591</td>
      <td>Sparklefest Ltd.</td>
      <td>$8.26</td>
      <td>$5.78</td>
      <td>$4,881.66</td>
      <td>$3,417.16</td>
      <td>$1,464.50</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Chair covers</td>
      <td>830</td>
      <td>Supply 4U</td>
      <td>$9.37</td>
      <td>$6.56</td>
      <td>$7,777.10</td>
      <td>$5,443.97</td>
      <td>$2,333.13</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Chair cushions</td>
      <td>745</td>
      <td>Supply 4U</td>
      <td>$13.82</td>
      <td>$9.67</td>
      <td>$10,295.90</td>
      <td>$7,207.13</td>
      <td>$3,088.77</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Chairs</td>
      <td>111</td>
      <td>Supply 4U</td>
      <td>$10.95</td>
      <td>$7.67</td>
      <td>$1,215.45</td>
      <td>$850.82</td>
      <td>$364.64</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 2.	Load tailing 8 rows to understand the dataset
df.tail(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Suppliers</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>26</th>
      <td>Serving utensils</td>
      <td>127</td>
      <td>Inflatibles Plus</td>
      <td>$3.09</td>
      <td>$2.16</td>
      <td>$392.43</td>
      <td>$274.70</td>
      <td>$117.73</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Spoons (50 count)</td>
      <td>927</td>
      <td>Eco-Disposables</td>
      <td>$2.49</td>
      <td>$1.74</td>
      <td>$2,308.23</td>
      <td>$1,615.76</td>
      <td>$692.47</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Streamers</td>
      <td>566</td>
      <td>Sparklefest Ltd.</td>
      <td>$2.67</td>
      <td>$1.87</td>
      <td>$1,511.22</td>
      <td>$1,057.85</td>
      <td>$453.37</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Table skirts</td>
      <td>1289</td>
      <td>Supply 4U</td>
      <td>$8.50</td>
      <td>$5.95</td>
      <td>$10,956.50</td>
      <td>$7,669.55</td>
      <td>$3,286.95</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Tablecloths</td>
      <td>328</td>
      <td>Supply 4U</td>
      <td>$9.19</td>
      <td>$6.43</td>
      <td>$3,014.32</td>
      <td>$2,110.02</td>
      <td>$904.30</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Tables</td>
      <td>150</td>
      <td>Supply 4U</td>
      <td>$36.20</td>
      <td>$25.34</td>
      <td>$5,430.00</td>
      <td>$3,801.00</td>
      <td>$1,629.00</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Tents</td>
      <td>535</td>
      <td>Inflatibles Plus</td>
      <td>$209.07</td>
      <td>$146.35</td>
      <td>$111,852.45</td>
      <td>$78,296.72</td>
      <td>$33,555.74</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Toothpicks (500 count)</td>
      <td>1386</td>
      <td>Eco-Disposables</td>
      <td>$1.59</td>
      <td>$1.11</td>
      <td>$2,203.74</td>
      <td>$1,542.62</td>
      <td>$661.12</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 3.	Check number of rows and columns in the dataset
df.shape
```




    (34, 8)




```python
# 4.	Check the data types of the columns
df.dtypes
```




    Product                  object
    Purchase Orders           int64
    Suppliers                object
    Price                    object
    Expenditure per piece    object
    Revenue                  object
    Total expenditure        object
    Profit                   object
    dtype: object




```python
# 5.	Check for datatypes and null values in dataset
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 34 entries, 0 to 33
    Data columns (total 8 columns):
     #   Column                 Non-Null Count  Dtype 
    ---  ------                 --------------  ----- 
     0   Product                34 non-null     object
     1   Purchase Orders        34 non-null     int64 
     2   Suppliers              34 non-null     object
     3   Price                  34 non-null     object
     4   Expenditure per piece  34 non-null     object
     5   Revenue                34 non-null     object
     6   Total expenditure      34 non-null     object
     7   Profit                 34 non-null     object
    dtypes: int64(1), object(7)
    memory usage: 2.3+ KB
    


```python
# 6.	Observation: It has been observed through #5 and #6 that the data types in columns Price, Expenditure per piece, Revenue, Total expenditure, and Profit appear as ‘object’ data type instead of float as they are numerical columns instead of strings
# 7.	Let’s further investigate to see why the float data type appears as ‘object’ data type

df.describe(include = 'object')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Suppliers</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>34</td>
      <td>5</td>
      <td>32</td>
      <td>32</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
    </tr>
    <tr>
      <th>top</th>
      <td>Balloons (100 count)</td>
      <td>Eco-Disposables</td>
      <td>$2.49</td>
      <td>$1.74</td>
      <td>$13,145.44</td>
      <td>$9,201.81</td>
      <td>$3,943.63</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 8.	Observation: It has been observed above that due to $ sign the pandas interpret the cells as ‘object’ datatype instead of float
# 9.	Let’s convert the object datatype to float

# Columns to convert
columns_to_convert = ['Price', 'Expenditure per piece', 'Revenue', 'Total expenditure', 'Profit']

# Function to clean and convert currency strings to float
def clean_currency(value):
    return float(value.replace('$', '').replace(',', ''))

# Apply the function to the specified columns
for col in columns_to_convert:
    df[col] = df[col].apply(clean_currency)
```


```python
# 10.	Verify if the data type has been changed
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 34 entries, 0 to 33
    Data columns (total 8 columns):
     #   Column                 Non-Null Count  Dtype  
    ---  ------                 --------------  -----  
     0   Product                34 non-null     object 
     1   Purchase Orders        34 non-null     int64  
     2   Suppliers              34 non-null     object 
     3   Price                  34 non-null     float64
     4   Expenditure per piece  34 non-null     float64
     5   Revenue                34 non-null     float64
     6   Total expenditure      34 non-null     float64
     7   Profit                 34 non-null     float64
    dtypes: float64(5), int64(1), object(2)
    memory usage: 2.3+ KB
    


```python
# 11.	Use statistical methods to find any outliers in the dataset. From the following, it has been observed that there are no outliers in the dataset.
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Purchase Orders</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>34.000000</td>
      <td>34.000000</td>
      <td>34.000000</td>
      <td>34.000000</td>
      <td>34.000000</td>
      <td>34.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>642.735294</td>
      <td>27.707353</td>
      <td>19.395000</td>
      <td>8057.416765</td>
      <td>5640.191765</td>
      <td>2417.226176</td>
    </tr>
    <tr>
      <th>std</th>
      <td>369.204001</td>
      <td>75.779240</td>
      <td>53.046105</td>
      <td>19053.401747</td>
      <td>13337.381998</td>
      <td>5716.021117</td>
    </tr>
    <tr>
      <th>min</th>
      <td>24.000000</td>
      <td>0.820000</td>
      <td>0.570000</td>
      <td>334.390000</td>
      <td>234.070000</td>
      <td>100.320000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>301.000000</td>
      <td>2.490000</td>
      <td>1.740000</td>
      <td>1289.392500</td>
      <td>902.577500</td>
      <td>386.822500</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>721.000000</td>
      <td>5.470000</td>
      <td>3.830000</td>
      <td>3089.195000</td>
      <td>2162.435000</td>
      <td>926.760000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>869.250000</td>
      <td>10.555000</td>
      <td>7.392500</td>
      <td>7295.550000</td>
      <td>5106.885000</td>
      <td>2188.665000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1386.000000</td>
      <td>396.340000</td>
      <td>277.440000</td>
      <td>111852.450000</td>
      <td>78296.720000</td>
      <td>33555.740000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 12.	Since we are analyzing the dataset regarding suppliers it is important to query and errors in the supplier's column. The data type of the suppliers’ column is object therefore it is important to query columns with object data type
for col in df.describe(include = 'object').columns:
    print(col)
    print(df[col].unique())
    print('-'*50)
```

    Product
    ['Balloons (100 count)' 'Banners' 'Bounce house' 'Bowls (25 count)'
     'Centerpieces' 'Chair covers' 'Chair cushions' 'Chairs'
     'Coasters (50 count)' 'Cocktail napkins (100 count)'
     'Cocktail plates (40 count)' 'Confetti (65 count)' 'Forks (50 count)'
     'Goody bags (10 count)' 'Ice buckets' 'Invitations (20 count)'
     'Knives (50 count)' 'Ladles' 'Name tags (20 count)'
     'Noisemakers (30 count)' 'Outdoor heaters' 'Party hats (10 count)'
     'Piñatas' 'Plates (25 count)' 'Punch bowls' 'Serving platters'
     'Serving utensils' 'Spoons (50 count)' 'Streamers' 'Table skirts'
     'Tablecloths' 'Tables' 'Tents' 'Toothpicks (500 count)']
    --------------------------------------------------
    Suppliers
    ['Sparklefest Ltd.' 'Inflatibles Plus' 'Inflatibles Plos'
     'Eco-Disposables' 'Supply 4U']
    --------------------------------------------------
    


```python
# 13.	Observation: It has been observed there is an error in suppliers column the ‘Inflatibles Plus’ has been misspelled as ‘Inflatibles Plos’.
 
# 14.	Correct the supplier name Inflatibles Plos to Inflatible Plus

df['Suppliers'] = df['Suppliers'].replace('Inflatibles Plos', 'Inflatibles Plus')
```


```python
df['Suppliers'].unique()
```




    array(['Sparklefest Ltd.', 'Inflatibles Plus', 'Eco-Disposables',
           'Supply 4U'], dtype=object)




```python
# 15.	Group the data by suppliers to simplify for finding trends
grouped_suppliers = df.groupby('Suppliers').sum()
grouped_suppliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Suppliers</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Eco-Disposables</th>
      <td>Bowls (25 count)Coasters (50 count)Cocktail na...</td>
      <td>9177</td>
      <td>29.18</td>
      <td>20.42</td>
      <td>26825.52</td>
      <td>18777.88</td>
      <td>8047.66</td>
    </tr>
    <tr>
      <th>Inflatibles Plus</th>
      <td>BannersBounce houseIce bucketsLadlesOutdoor he...</td>
      <td>2781</td>
      <td>750.20</td>
      <td>525.15</td>
      <td>147571.09</td>
      <td>103299.76</td>
      <td>44271.34</td>
    </tr>
    <tr>
      <th>Sparklefest Ltd.</th>
      <td>Balloons (100 count)CenterpiecesConfetti (65 c...</td>
      <td>6442</td>
      <td>74.64</td>
      <td>52.24</td>
      <td>60866.29</td>
      <td>42606.39</td>
      <td>18259.90</td>
    </tr>
    <tr>
      <th>Supply 4U</th>
      <td>Chair coversChair cushionsChairsTable skirtsTa...</td>
      <td>3453</td>
      <td>88.03</td>
      <td>61.62</td>
      <td>38689.27</td>
      <td>27082.49</td>
      <td>11606.79</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 16.	Observation:  From the above visualization it can be said that Jeff’s Party Planet ordered less from Inflatibles Plus but got high profits. 
# 17.	Let’s analyze profitability per supplier

total_profit = grouped_suppliers['Profit'].sum()
grouped_suppliers['Profit Perc'] = grouped_suppliers['Profit'] / total_profit * 100
grouped_suppliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
      <th>Profit Perc</th>
    </tr>
    <tr>
      <th>Suppliers</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Eco-Disposables</th>
      <td>Bowls (25 count)Coasters (50 count)Cocktail na...</td>
      <td>9177</td>
      <td>29.18</td>
      <td>20.42</td>
      <td>26825.52</td>
      <td>18777.88</td>
      <td>8047.66</td>
      <td>9.792045</td>
    </tr>
    <tr>
      <th>Inflatibles Plus</th>
      <td>BannersBounce houseIce bucketsLadlesOutdoor he...</td>
      <td>2781</td>
      <td>750.20</td>
      <td>525.15</td>
      <td>147571.09</td>
      <td>103299.76</td>
      <td>44271.34</td>
      <td>53.867456</td>
    </tr>
    <tr>
      <th>Sparklefest Ltd.</th>
      <td>Balloons (100 count)CenterpiecesConfetti (65 c...</td>
      <td>6442</td>
      <td>74.64</td>
      <td>52.24</td>
      <td>60866.29</td>
      <td>42606.39</td>
      <td>18259.90</td>
      <td>22.217858</td>
    </tr>
    <tr>
      <th>Supply 4U</th>
      <td>Chair coversChair cushionsChairsTable skirtsTa...</td>
      <td>3453</td>
      <td>88.03</td>
      <td>61.62</td>
      <td>38689.27</td>
      <td>27082.49</td>
      <td>11606.79</td>
      <td>14.122641</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 18.	Observation: The above  visualization shows that Jeff’s Party Planet has drived higher profits Inflatible Plus
# 19.	Let us analyze profit margin per supplier

grouped_suppliers['Profit Margin'] = grouped_suppliers['Profit'] / grouped_suppliers['Total expenditure'] * 100
grouped_suppliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purchase Orders</th>
      <th>Price</th>
      <th>Expenditure per piece</th>
      <th>Revenue</th>
      <th>Total expenditure</th>
      <th>Profit</th>
      <th>Profit Perc</th>
      <th>Profit Margin</th>
    </tr>
    <tr>
      <th>Suppliers</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Eco-Disposables</th>
      <td>Bowls (25 count)Coasters (50 count)Cocktail na...</td>
      <td>9177</td>
      <td>29.18</td>
      <td>20.42</td>
      <td>26825.52</td>
      <td>18777.88</td>
      <td>8047.66</td>
      <td>9.792045</td>
      <td>42.857128</td>
    </tr>
    <tr>
      <th>Inflatibles Plus</th>
      <td>BannersBounce houseIce bucketsLadlesOutdoor he...</td>
      <td>2781</td>
      <td>750.20</td>
      <td>525.15</td>
      <td>147571.09</td>
      <td>103299.76</td>
      <td>44271.34</td>
      <td>53.867456</td>
      <td>42.857157</td>
    </tr>
    <tr>
      <th>Sparklefest Ltd.</th>
      <td>Balloons (100 count)CenterpiecesConfetti (65 c...</td>
      <td>6442</td>
      <td>74.64</td>
      <td>52.24</td>
      <td>60866.29</td>
      <td>42606.39</td>
      <td>18259.90</td>
      <td>22.217858</td>
      <td>42.857186</td>
    </tr>
    <tr>
      <th>Supply 4U</th>
      <td>Chair coversChair cushionsChairsTable skirtsTa...</td>
      <td>3453</td>
      <td>88.03</td>
      <td>61.62</td>
      <td>38689.27</td>
      <td>27082.49</td>
      <td>11606.79</td>
      <td>14.122641</td>
      <td>42.857175</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sharing
#I have finished analyzing data. Let’s visualize it through visualization in matplotlib library of Python.
# 20.	Visualize the data by suppliers to find patterns

```


```python
# 21.	Visualize the data by suppliers to find patterns
grouped_suppliers.plot(kind='line',figsize=(5,3))
plt.title("Jeff's Party Planet Suppliers Data")
plt.xlabel('Suppliers')
plt.ylabel('Sum of Values')
```




    Text(0, 0.5, 'Sum of Values')




    
![png](output_21_1.png)
    



```python
# 22.	Let’s visualize profitability per supplier
grouped_suppliers['Profit Perc'].plot(kind='bar',figsize=(5,3))
plt.title("Jeff's Party Planet Suppliers Data")
plt.xlabel('Suppliers')
plt.ylabel('Sum of Values')
```




    Text(0, 0.5, 'Sum of Values')




    
![png](output_22_1.png)
    



```python
# 23 Plotting the profit margin for each supplier
plt.figure(figsize=(5, 3))
grouped_suppliers['Profit Margin'].plot(kind='bar', color='skyblue', alpha=0.7)
plt.title('Profit Margin by Supplier')
plt.xlabel('Suppliers')
plt.ylabel('Profit Margin (%)')
plt.show()
```


    
![png](output_23_0.png)
    



```python
# 24.	From the above visualization it is evident that all the suppliers are equally profitable.
```
